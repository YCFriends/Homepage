# Y.C.& Friends Website

Welcome to the official Y.C.& Friends homepage repository!

## 🌐 Demo

Live site: [https://your-github-username.github.io/yc-and-friends](https://your-github-username.github.io/yc-and-friends)

## 📁 Project Structure

```
yc-and-friends/
├── index.html
├── assets/
│   └── images/
└── README.md
```

## 🚀 Deployment on GitHub Pages

1. Clone or upload this repo to GitHub.
2. Go to **Settings > Pages**.
3. Set source to `main` branch and root directory.
4. Done! Your site will be live shortly.

## 📬 Contact

hello@ycandfriends.com  
Instagram: @yc.and.friends
